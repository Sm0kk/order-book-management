package order.book.management.strategy.handler;

import java.util.List;

public interface ReportHandler {
    String getOutputData(List<String> data);
}
