package order.book.management.service;

public interface WriterService {
    void write(String data, String filePath);
}
