package order.book.management.service;

import java.util.List;

public interface ReportService {
    String getOutputData(List<String> data);
}
