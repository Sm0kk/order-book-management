package order.book.management.db;

import java.util.ArrayList;
import java.util.List;
import order.book.management.model.Order;

public class Storage {
    public static final List<Order> orders = new ArrayList<>();
}
